/**
 * dxLogger module.
 * A simple, static logger that replaces `console.log`.
 * It provides multi-level logging and can be viewed in the corresponding VSCode plugin during debugging.
 *
 * Features:
 * - Three log levels: DEBUG, INFO, ERROR. All levels are always enabled.
 * - Supports logging various JavaScript data types, including objects and errors.
 * - Non-blocking log output to avoid performance impact.
 *
 * Usage:
 * - Import the logger: `import log from './dxLogger.js'`
 * - Use the logging methods: `log.info('Application started');`, `log.error('An error occurred:', new Error('test'));`
 *
 * Doc/Demo: https://github.com/DejaOS/DejaOS
 */
const logger = {}
import * as std from "std"
/**
 * Logs a message at the DEBUG level.
 * @param {...*} data - The data to log. Can be multiple arguments of any type.
 * @example
 * logger.debug('User logged in:', { userId: 123 });
 */
logger.debug = function (...data) {
    log("DEBUG", data)
}

/**
 * Logs a message at the INFO level.
 * @param {...*} data - The data to log. Can be multiple arguments of any type.
 * @example
 * logger.info('Server started on port', 8080);
 */
logger.info = function (...data) {
    log("INFO", data)
}

/**
 * Logs a message at the ERROR level.
 * @param {...*} data - The data to log. Can be multiple arguments of any type.
 * @example
 * try {
 *   // ... some code that might fail
 * } catch (e) {
 *   logger.error('Operation failed:', e);
 * }
 */
logger.error = function (...data) {
    log("ERROR", data)
}
//-----------------------------------private----------------------
// Formats and prints the log message to standard output.
function log(level, messages) {
    const message = messages.map(msg => getContent(msg)).join(' ');
    const content = `[${level} ${getTime()}]: ${message}`;
    try {
        std.puts(content + '\n');
        std.out.flush(); // Ensure the log is written immediately.
    } catch (e) {
        // If puts fails, there is not much we can do.
        // Avoid crashing the application because of a log failure.
    }
}
// Converts any JavaScript value to a string for logging.
function getContent(message) {
    if (message === undefined) {
        return 'undefined'
    } else if (message === null) {
        return 'null'
    }
    if (typeof message === 'object') {
        if (Object.prototype.toString.call(message) === '[object Error]') {
            return message.message + '\n' + message.stack
        }
        return JSON.stringify(message)
    }
    return String(message);
}
// Generates a timestamp string in 'YYYY-MM-DD HH:mm:ss.ms' format.
function getTime() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const milliseconds = String(now.getMilliseconds()).padStart(3, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${milliseconds}`;
}
export default logger