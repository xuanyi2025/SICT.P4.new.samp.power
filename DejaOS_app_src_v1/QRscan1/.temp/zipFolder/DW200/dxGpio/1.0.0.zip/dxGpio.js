import { gpioClass } from '/usr/lib/libvbar-b-dxgpio.so'

const gpioObj = new gpioClass();

const gpio = {

	/**
	 * 初始化
	 * @returns JS_UNDEFINED
	 */
	init() {
		return gpioObj.init();
	},


	/**
	 * 释放gpio资源
	 * @returns JS_UNDEFINED
	 */
	exit() {
		return gpioObj.exit();
	},


	/**
	 * 申请gpio
	 * @param {*} gpio_ 
	 * @returns res(int)
	 */
	request(gpio_) {
		return gpioObj.request(gpio_)
	},


	/**
	 * 释放指定gpio
	 * @param {*} gpio_ 
	 * @returns JS_UNDEFINED
	 */
	free(gpio_) {
		return gpioObj.free(gpio_);
	},


	/**
	 * 设置指定gpio功能
	 * @param {*} gpio_ 
	 * @param {*} func 
	 * @returns JS_UNDEFINED
	 */
	setFunc(gpio_, func) {
		return gpioObj.setFunc(gpio_, func);
	},


	/**
	 * 设置指定gpio上拉状态
	 * @param {*} gpio_ 
	 * @param {*} state 
	 * @returns JS_UNDEFINED
	 */
	setPullState(gpio_, state) {
		return gpioObj.setPullState(gpio_, state);
	},


	/**
	 * 获取指定gpio上拉状态
	 * @param {*} gpio_ 
	 * @returns res(int)
	 */
	getPullState(gpio_) {
		return gpioObj.getPullState(gpio_);
	},


	/**
	 * 设置指定gpio的值
	 * @param {*} gpio_ 
	 * @param {*} value 
	 * @returns JS_UNDEFINED
	 */
	setValue(gpio_, value) {
		return gpioObj.setValue(gpio_, value);
	},


	/**
	 * 获取指定gpio值
	 * @param {*} gpio_ 
	 * @returns res(int)
	 */
	getValue(gpio_) {
		return gpioObj.getValue(gpio_);
	},


	/**
	 * 设置指定gpio的驱动能力
	 * @param {*} gpio_ 
	 * @param {*} strength 
	 * @returns res(int)
	 */
	setDriveStrength(gpio_, strength) {
		return gpioObj.setDriveStrength(gpio_, strength);
	},


	/**
	 * 获取指定gpio的驱动能力
	 * @param {*} gpio_ 
	 * @returns res(int)
	 */
	getDriveStrength(gpio_) {
		return gpioObj.getDriveStrength(gpio_);
	},
}

export default gpio;